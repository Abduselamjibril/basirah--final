import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  TextField,
  Typography,
  Card,
  CardContent,
  CardMedia,
  IconButton,
} from '@mui/material';
import { Delete as DeleteIcon, Lock, LockOpen } from '@mui/icons-material';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const StoryEpisodeManager = () => {
  const { storyId } = useParams();
  const [episodes, setEpisodes] = useState([]);
  const [newEpisodeTitle, setNewEpisodeTitle] = useState('');
  const [newEpisodeVideo, setNewEpisodeVideo] = useState(null);
  const [newEpisodeAudio, setNewEpisodeAudio] = useState(null);
  const [youtubeLink, setYoutubeLink] = useState('');
  const [isYouTube, setIsYouTube] = useState(false);

  useEffect(() => {
    fetchEpisodes();
  }, [storyId]);

  const fetchEpisodes = async () => {
    try {
      const response = await axios.get(`http://127.0.0.1:8000/api/stories/${storyId}/episodes`);
      setEpisodes(response.data);
    } catch (error) {
      console.error('Error fetching episodes:', error);
    }
  };

  const addEpisode = async () => {
    const formData = new FormData();
    formData.append('name', newEpisodeTitle);
    if (isYouTube) {
      formData.append('youtube_link', youtubeLink);
    } else {
      if (newEpisodeVideo) {
        formData.append('video', newEpisodeVideo);
      }
    }
    if (newEpisodeAudio) {
      formData.append('audio', newEpisodeAudio);
    }

    try {
      await axios.post(`http://127.0.0.1:8000/api/stories/${storyId}/episodes`, formData);
      await resetForm();
      fetchEpisodes();
    } catch (error) {
      console.error('Error adding episode:', error.response ? error.response.data : error);
    }
  };

  const resetForm = async () => {
    setNewEpisodeTitle('');
    setNewEpisodeVideo(null);
    setNewEpisodeAudio(null);
    setYoutubeLink('');
    setIsYouTube(false);
  };

  const deleteEpisode = async (episodeId) => {
    try {
      await axios.delete(`http://127.0.0.1:8000/api/episodes/${episodeId}`);
      fetchEpisodes();
    } catch (error) {
      console.error('Error deleting episode:', error.response ? error.response.data : error);
    }
  };

  const toggleLock = async (episode) => {
    try {
      const action = episode.is_locked ? 'unlock' : 'lock';
      await axios.post(`http://127.0.0.1:8000/api/episodes/${episode.id}/${action}`);
      fetchEpisodes();
    } catch (error) {
      console.error('Error toggling lock state:', error);
    }
  };

  return (
    <Box m="20px">
      <Typography variant="h5">Manage Episodes for Story {storyId}</Typography>
      <TextField
        label="Episode Title"
        value={newEpisodeTitle}
        onChange={(e) => setNewEpisodeTitle(e.target.value)}
        fullWidth
        margin="normal"
      />
      <Box display="flex" gap={2} mb={2}>
        <Button 
          variant={isYouTube ? 'contained' : 'outlined'} 
          onClick={() => setIsYouTube(true)}
        >
          YouTube Link
        </Button>
        <Button 
          variant={!isYouTube ? 'contained' : 'outlined'} 
          onClick={() => setIsYouTube(false)}
        >
          Upload Video
        </Button>
      </Box>
      {isYouTube && (
        <TextField
          label="YouTube Link"
          value={youtubeLink}
          onChange={(e) => setYoutubeLink(e.target.value)}
          fullWidth
          margin="normal"
          placeholder="https://www.youtube.com/watch?v=VIDEO_ID"
        />
      )}
      {!isYouTube && (
        <input
          type="file"
          onChange={(e) => setNewEpisodeVideo(e.target.files[0])}
          accept="video/*"
          style={{ marginTop: 10 }}
        />
      )}
      <input
        type="file"
        onChange={(e) => setNewEpisodeAudio(e.target.files[0])}
        accept="audio/*"
        style={{ marginTop: 10 }}
      />
      <Button onClick={addEpisode} variant="contained" color="primary" sx={{ mt: 2 }}>
        Add Episode
      </Button>
      <Box mt={2} display="flex" flexWrap="wrap" gap={2}>
        {episodes.map(episode => (
          <Card key={episode.id} sx={{ width: 300 }}>
            {episode.video && !episode.youtube_link && (
              <CardMedia
                component="video"
                controls
                src={`http://127.0.0.1:8000/storage/${episode.video}`}
              />
            )}
            {episode.youtube_link && (
              <iframe
                width="100%"
                height="150"
                src={episode.youtube_link.replace("watch?v=", "embed/")}
                title={episode.name}
                frameBorder="0"
                allowFullScreen
              />
            )}
            {episode.audio && (
              <audio controls>
                <source src={`http://127.0.0.1:8000/storage/${episode.audio}`} type="audio/mpeg" />
              </audio>
            )}
            <CardContent>
              <Typography variant="h6">{episode.name}</Typography>
              <IconButton onClick={() => toggleLock(episode)} color="warning">
                {episode.is_locked ? <Lock /> : <LockOpen />}
              </IconButton>
              <IconButton onClick={() => deleteEpisode(episode.id)} color="error">
                <DeleteIcon />
              </IconButton>
            </CardContent>
          </Card>
        ))}
      </Box>
    </Box>
  );
};

export default StoryEpisodeManager;