import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Box,
  Button,
  TextField,
  Typography,
  Card,
  CardContent,
  CardMedia,
  IconButton,
  Alert,
  Tooltip,
} from '@mui/material';
import { Edit, Delete, AddCircle, Lock, LockOpen } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const API_URL = 'http://127.0.0.1:8000/api/stories';
const BASE_IMAGE_URL = 'http://127.0.0.1:8000/storage/';

const StoryManager = () => {
  const [stories, setStories] = useState([]);
  const [newStoryName, setNewStoryName] = useState('');
  const [newStoryDescription, setNewStoryDescription] = useState('');
  const [newStoryImage, setNewStoryImage] = useState(null);
  const [editingStoryId, setEditingStoryId] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchStories();
  }, []);

  const fetchStories = async () => {
    try {
      const response = await axios.get(API_URL);
      setStories(response.data); // Assuming the response is an array based on your document
    } catch (err) {
      setError('Failed to fetch stories');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const formData = new FormData();
    formData.append('name', newStoryName);
    formData.append('description', newStoryDescription);
    if (newStoryImage) {
      formData.append('image', newStoryImage);
    }

    try {
      if (editingStoryId) {
        await axios.post(`${API_URL}/${editingStoryId}?_method=PUT`, formData);
        setSuccess('Story updated successfully!');
      } else {
        await axios.post(API_URL, formData);
        setSuccess('Story created successfully!');
      }

      fetchStories();
      resetForm();
    } catch (err) {
      setError('Failed to submit story');
    }
  };

  const handleEdit = (story) => {
    setNewStoryName(story.name);
    setNewStoryDescription(story.description);
    setEditingStoryId(story.id);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      fetchStories();
      setSuccess('Story deleted successfully!');
    } catch (err) {
      setError('Failed to delete story');
    }
  };

  const toggleLock = async (story) => {
    try {
      if (story.is_premium) {
        await axios.post(`${API_URL}/${story.id}/unlock`);
        setSuccess('Story unlocked successfully!');
      } else {
        await axios.post(`${API_URL}/${story.id}/lock`);
        setSuccess('Story locked successfully!');
      }
      fetchStories();
    } catch (err) {
      setError('Failed to toggle lock state');
    }
  };

  const resetForm = () => {
    setNewStoryName('');
    setNewStoryDescription('');
    setNewStoryImage(null);
    setEditingStoryId(null);
    setError('');
    setSuccess('');
  };

  return (
    <Box m="20px">
      <Typography variant="h5" color="textPrimary">Story Manager</Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Story Name"
          value={newStoryName}
          onChange={(e) => setNewStoryName(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          label="Story Description"
          value={newStoryDescription}
          onChange={(e) => setNewStoryDescription(e.target.value)}
          fullWidth
          multiline
          rows={4}
          margin="normal"
          required
        />
        <input
          type="file"
          onChange={(e) => setNewStoryImage(e.target.files[0])}
          accept="image/*"
          style={{ display: 'block', margin: '10px 0' }}
        />

        {error && <Alert severity="error">{error}</Alert>}
        {success && <Alert severity="success">{success}</Alert>}

        <Button variant="contained" color="primary" type="submit" sx={{ mt: 2 }}>
          {editingStoryId ? 'Update Story' : 'Create Story'}
        </Button>
      </form>

      <Box mt={2} display="flex" flexWrap="wrap" gap={2}>
        {stories.map((story) => (
          <Card key={story.id} sx={{ width: 300 }}>
            {story.image && ( // Ensure image exists before rendering
              <CardMedia
                component="img"
                height="flex"
                image={`${BASE_IMAGE_URL}${story.image}`}
                alt={story.name}
              />
            )}
            <CardContent>
              <Typography variant="h6">{story.name}</Typography>
              <Typography variant="body2" color="textSecondary">
                {story.description}
              </Typography>
            </CardContent>
            <Box display="flex" justifyContent="space-between" p={1}>
              <IconButton onClick={() => handleEdit(story)} color="white">
                <Edit />
              </IconButton>
              <IconButton onClick={() => handleDelete(story.id)} color="error">
                <Delete />
              </IconButton>
              <Tooltip title={story.is_premium ? "Unlock Story" : "Lock Story"}>
                <IconButton onClick={() => toggleLock(story)} color="warning">
                  {story.is_premium ? <Lock /> : <LockOpen />}
                </IconButton>
              </Tooltip>
              <Tooltip title="Add Episode">
                <IconButton
                  onClick={() => navigate(`/upload/story/${story.id}/episodes`)}
                  color="white"
                >
                  <AddCircle />
                </IconButton>
              </Tooltip>
            </Box>
          </Card>
        ))}
      </Box>
    </Box>
  );
};

export default StoryManager;