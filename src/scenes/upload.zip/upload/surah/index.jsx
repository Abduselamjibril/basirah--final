import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Box,
  Button,
  TextField,
  Typography,
  Card,
  CardContent,
  CardMedia,
  IconButton,
  Alert,
  Tooltip,
} from '@mui/material';
import { Edit, Delete, AddCircle, Lock, LockOpen } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const API_URL = 'http://127.0.0.1:8000/api/surahs';
const BASE_IMAGE_URL = 'http://127.0.0.1:8000/storage/';

const SurahManager = () => {
  const [surahs, setSurahs] = useState([]);
  const [newSurahName, setNewSurahName] = useState('');
  const [newSurahDescription, setNewSurahDescription] = useState('');
  const [newSurahImage, setNewSurahImage] = useState(null);
  const [editingSurahId, setEditingSurahId] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchSurahs();
  }, []);

  const fetchSurahs = async () => {
    try {
      const response = await axios.get(API_URL);
      setSurahs(response.data);
    } catch (err) {
      setError('Failed to fetch surahs');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const formData = new FormData();
    formData.append('name', newSurahName);
    formData.append('description', newSurahDescription);
    if (newSurahImage) {
      formData.append('image', newSurahImage);
    }

    try {
      if (editingSurahId) {
        await axios.post(`${API_URL}/${editingSurahId}?_method=PUT`, formData);
        setSuccess('Surah updated successfully!');
      } else {
        await axios.post(API_URL, formData);
        setSuccess('Surah created successfully!');
      }

      fetchSurahs();
      resetForm();
    } catch (err) {
      setError('Failed to submit surah: ' + err.response?.data?.error || err.message);
    }
  };

  const handleEdit = (surah) => {
    setNewSurahName(surah.name);
    setNewSurahDescription(surah.description);
    setEditingSurahId(surah.id);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      fetchSurahs();
      setSuccess('Surah deleted successfully!');
    } catch (err) {
      setError('Failed to delete surah: ' + err.response?.data?.error || err.message);
    }
  };

  const toggleLock = async (surah) => {
    try {
      if (surah.is_premium) {
        await axios.post(`${API_URL}/${surah.id}/unlock`);
        setSuccess('Surah unlocked successfully!');
      } else {
        await axios.post(`${API_URL}/${surah.id}/lock`);
        setSuccess('Surah locked successfully!');
      }
      fetchSurahs();
    } catch (err) {
      setError('Failed to toggle lock state: ' + err.response?.data?.error || err.message);
    }
  };

  const resetForm = () => {
    setNewSurahName('');
    setNewSurahDescription('');
    setNewSurahImage(null);
    setEditingSurahId(null);
    setError('');
    setSuccess('');
  };

  return (
    <Box m="20px">
      <Typography variant="h5" color="textPrimary">Surah Manager</Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Surah Name"
          value={newSurahName}
          onChange={(e) => setNewSurahName(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          label="Surah Description"
          value={newSurahDescription}
          onChange={(e) => setNewSurahDescription(e.target.value)}
          fullWidth
          multiline
          rows={4}
          margin="normal"
          required
        />
        <input
          type="file"
          onChange={(e) => setNewSurahImage(e.target.files[0])}
          accept="image/*"
          style={{ display: 'block', margin: '10px 0' }}
        />
        {error && <Alert severity="error">{error}</Alert>}
        {success && <Alert severity="success">{success}</Alert>}
        <Button variant="contained" color="primary" type="submit" sx={{ mt: 2 }}>
          {editingSurahId ? 'Update Surah' : 'Create Surah'}
        </Button>
      </form>
      <Box mt={2} display="flex" flexWrap="wrap" gap={2}>
        {surahs.map((surah) => (
          <Card key={surah.id} sx={{ width: 300 }}>
            {surah.image && (
              <CardMedia
                component="img"
                height="flex"
                image={`${BASE_IMAGE_URL}${surah.image}`}
                alt={surah.name}
              />
            )}
            <CardContent>
              <Typography variant="h6">{surah.name}</Typography>
              <Typography variant="body2" color="textSecondary">
                {surah.description}
              </Typography>
            </CardContent>
            <Box display="flex" justifyContent="space-between" p={1}>
              <IconButton onClick={() => handleEdit(surah)} color="white">
                <Edit />
              </IconButton>
              <IconButton onClick={() => handleDelete(surah.id)} color="error">
                <Delete />
              </IconButton>
              <Tooltip title={surah.is_premium ? "Unlock Surah" : "Lock Surah"}>
                <IconButton onClick={() => toggleLock(surah)} color="warning">
                  {surah.is_premium ? <Lock /> : <LockOpen />}
                </IconButton>
              </Tooltip>
              <Tooltip title="Add Episode">
                <IconButton
                  onClick={() => navigate(`/upload/surah/${surah.id}/episodes`)}
                  color="white"
                >
                  <AddCircle />
                </IconButton>
              </Tooltip>
            </Box>
          </Card>
        ))}
      </Box>
    </Box>
  );
};

export default SurahManager;