import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  TextField,
  IconButton,
  Card,
  CardContent,
  Typography,
  Tooltip,
} from '@mui/material';
import { Edit, Delete, AddCircle } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ArabicManager = () => {
  const [arabics, setArabics] = useState([]);
  const [newArabicName, setNewArabicName] = useState('');
  const [newArabicDescription, setNewArabicDescription] = useState('');
  const [newArabicImage, setNewArabicImage] = useState(null);
  const [editingArabicId, setEditingArabicId] = useState(null);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Fetch arabics
  const fetchArabics = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://127.0.0.1:8000/api/arabics');
      setArabics(response.data);
    } catch (error) {
      console.error('Error fetching arabics:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchArabics();
  }, []);

  // Add or update Arabic
  const handleArabicSubmit = async () => {
    const formData = new FormData();
    formData.append('name', newArabicName);
    formData.append('description', newArabicDescription);

    if (newArabicImage) {
      formData.append('image', newArabicImage);
    }

    try {
      if (editingArabicId) {
        await axios.put(
          `http://127.0.0.1:8000/api/arabics/${editingArabicId}`,
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          }
        );
      } else {
        await axios.post(
          'http://127.0.0.1:8000/api/arabics',
          formData,
          {
            headers: {
              'Content-Type': 'multipart/form-data',
            },
          }
        );
      }

      // Refresh the list and clear the form
      fetchArabics();
      setNewArabicName('');
      setNewArabicDescription('');
      setNewArabicImage(null);
      setEditingArabicId(null);
      setErrors({});
    } catch (error) {
      if (error.response && error.response.data.errors) {
        setErrors(error.response.data.errors);
      } else {
        console.error('Error saving Arabic:', error);
      }
    }
  };

  // Edit Arabic
  const editArabic = (arabic) => {
    setNewArabicName(arabic.name);
    setNewArabicDescription(arabic.description);
    setNewArabicImage(null);
    setEditingArabicId(arabic.id);
  };

  // Delete Arabic
  const deleteArabic = async (id) => {
    try {
      await axios.delete(`http://127.0.0.1:8000/api/arabics/${id}`);
      fetchArabics(); // Re-fetch to update the list
    } catch (error) {
      console.error('Error deleting Arabic:', error);
    }
  };

  return (
    <Box m="20px">
      <Typography variant="h4">Arabic Management</Typography>

      {/* Loading Indicator */}
      {loading ? (
        <Typography>Loading...</Typography>
      ) : (
        <>
          <TextField
            label="Arabic Name"
            value={newArabicName}
            onChange={(e) => setNewArabicName(e.target.value)}
            fullWidth
            error={!!errors.name}
            helperText={errors.name ? errors.name[0] : ''}
          />
          <TextField
            label="Arabic Description"
            value={newArabicDescription}
            onChange={(e) => setNewArabicDescription(e.target.value)}
            fullWidth
            multiline
            rows={4}
          />
          <input
            type="file"
            onChange={(e) => setNewArabicImage(e.target.files[0])}
            accept="image/*"
          />
          <Button onClick={handleArabicSubmit} variant="contained" color="primary">
            {editingArabicId ? 'Update Arabic' : 'Add Arabic'}
          </Button>

          <Box mt={2} display="flex" flexWrap="wrap">
            {arabics.map((arabic) => (
              <Card key={arabic.id} sx={{ width: 250, margin: 1 }}>
                {arabic.image && (
                  <img
                    src={`http://127.0.0.1:8000/storage/${arabic.image}`}
                    alt={arabic.name}
                    style={{ height: 150, objectFit: 'cover', width: '100%' }}
                  />
                )}
                <CardContent>
                  <Typography variant="h6">{arabic.name}</Typography>
                  <Typography variant="body2">{arabic.description}</Typography>
                  <Box display="flex" justifyContent="space-between" mt={1}>
                    <Tooltip title="Edit">
                      <IconButton onClick={() => editArabic(arabic)}>
                        <Edit />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton onClick={() => deleteArabic(arabic.id)}>
                        <Delete />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Add Episode">
                      <IconButton
                        onClick={() =>
                          navigate(`/upload/arabic/${arabic.id}/episodes`)
                        }
                      >
                        <AddCircle />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </CardContent>
              </Card>
            ))}
          </Box>
        </>
      )}
    </Box>
  );
};

export default ArabicManager;
