import React, { useEffect, useState } from 'react';
import {
  Box,
  Button,
  TextField,
  Typography,
  Card,
  CardContent,
  CardMedia,
  IconButton,
} from '@mui/material';
import { Delete as DeleteIcon } from '@mui/icons-material';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const ArabicEpisodeManager = () => {
  const { arabicId } = useParams();
  const [episodes, setEpisodes] = useState([]);
  const [newEpisodeName, setNewEpisodeName] = useState('');
  const [newEpisodeVideo, setNewEpisodeVideo] = useState(null);
  const [newEpisodeAudio, setNewEpisodeAudio] = useState(null);
  const [youtubeLink, setYoutubeLink] = useState('');
  const [isYouTube, setIsYouTube] = useState(false); // Toggle between upload and YouTube link

  // Fetch episodes for the Arabic
  useEffect(() => {
    const fetchEpisodes = async () => {
      try {
        const response = await axios.get(`http://127.0.0.1:8000/api/arabics/${arabicId}/episodes`);
        setEpisodes(response.data);
      } catch (error) {
        console.error('Error fetching episodes:', error);
      }
    };
    fetchEpisodes();
  }, [arabicId]);

  // Add new episode
  const addEpisode = async () => {
    const formData = new FormData();
    formData.append('name', newEpisodeName);

    if (isYouTube) {
      formData.append('youtube_link', youtubeLink);
    } else {
      if (newEpisodeVideo) {
        formData.append('video', newEpisodeVideo);
      }
    }

    // Always include audio if provided
    if (newEpisodeAudio) {
      formData.append('audio', newEpisodeAudio);
    }

    try {
      await axios.post(`http://127.0.0.1:8000/api/arabics/${arabicId}/episodes`, formData);
      resetForm();
      // Refresh episodes
      const response = await axios.get(`http://127.0.0.1:8000/api/arabics/${arabicId}/episodes`);
      setEpisodes(response.data);
    } catch (error) {
      console.error('Error adding episode:', error.response ? error.response.data : error);
    }
  };

  const resetForm = () => {
    setNewEpisodeName('');
    setNewEpisodeVideo(null);
    setNewEpisodeAudio(null);
    setYoutubeLink('');
    setIsYouTube(false);
  };

  // Delete episode
  const deleteEpisode = async (episodeId) => {
    try {
      await axios.delete(`http://127.0.0.1:8000/api/arabics/${arabicId}/episodes/${episodeId}`);
      // Refresh episodes after deletion
      const response = await axios.get(`http://127.0.0.1:8000/api/arabics/${arabicId}/episodes`);
      setEpisodes(response.data);
    } catch (error) {
      console.error('Error deleting episode:', error.response ? error.response.data : error);
    }
  };

  return (
    <Box m="20px">
      <Typography variant="h5" color="textPrimary">Manage Episodes for Arabic {arabicId}</Typography>
      <TextField
        label="Episode Title"
        value={newEpisodeName}
        onChange={(e) => setNewEpisodeName(e.target.value)}
        fullWidth
        margin="normal"
      />
      
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
        <Button 
          variant={isYouTube ? 'contained' : 'outlined'} 
          onClick={() => setIsYouTube(true)} 
          sx={{ 
            mr: 1, 
            backgroundColor: isYouTube ? 'primary.main' : 'transparent', 
            color: isYouTube ? 'white' : 'text.primary' 
          }}
        >
          YouTube Link
        </Button>
        <Button 
          variant={!isYouTube ? 'contained' : 'outlined'} 
          onClick={() => setIsYouTube(false)} 
          sx={{ 
            backgroundColor: !isYouTube ? 'primary.main' : 'transparent', 
            color: !isYouTube ? 'white' : 'text.primary' 
          }}
        >
          Upload Video
        </Button>
      </Box>

      {/* YouTube Link Input: Only displayed when isYouTube is true */}
      {isYouTube && (
        <TextField
          label="YouTube Link"
          value={youtubeLink}
          onChange={(e) => setYoutubeLink(e.target.value)}
          fullWidth
          margin="normal"
          placeholder="https://www.youtube.com/watch?v=VIDEO_ID"
        />
      )}

      {/* Video Upload Input: Only shown when not using YouTube */}
      {!isYouTube && (
        <input
          type="file"
          onChange={(e) => setNewEpisodeVideo(e.target.files[0])}
          accept="video/*"
          style={{ display: 'block', margin: '10px 0' }} // Style for visibility
        />
      )}

      {/* Audio Upload Input: Always visible */}
      <input
        type="file"
        onChange={(e) => setNewEpisodeAudio(e.target.files[0])}
        accept="audio/*"
        style={{ display: 'block', margin: '10px 0' }} // Style for visibility
      />

      <Button onClick={addEpisode} variant="contained" color="primary" sx={{ mt: 2 }}>
        Add Episode
      </Button>

      <Box mt={2} display="flex" flexWrap="wrap" gap={2}>
        {episodes.map(episode => (
          <Card key={episode.id} sx={{ width: 300 }}>
            {episode.video && !episode.youtube_link && (
              <CardMedia
                component="video"
                controls
                src={`http://127.0.0.1:8000/storage/${episode.video}`}
                sx={{ height: 150 }}
              />
            )}
            {episode.youtube_link && (
              <iframe
                width="100%"
                height="150"
                src={episode.youtube_link.replace("watch?v=", "embed/")} // Convert to embed URL
                title={episode.name}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            )}
            {episode.audio && (
              <audio controls>
                <source src={`http://127.0.0.1:8000/storage/${episode.audio}`} type="audio/mpeg" />
                Your browser does not support the audio element.
              </audio>
            )}
            <CardContent>
              <Typography variant="h6">{episode.name}</Typography>
              <IconButton onClick={() => deleteEpisode(episode.id)} color="secondary">
                <DeleteIcon />
              </IconButton>
            </CardContent>
          </Card>
        ))}
      </Box>
    </Box>
  );
};

export default ArabicEpisodeManager;