import React, { useEffect, useState } from 'react';
import { Box, Button, TextField, Typography, Card, CardContent, CardMedia, IconButton, Alert } from '@mui/material';
import { Delete as DeleteIcon, Lock, LockOpen } from '@mui/icons-material';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const EpisodeManager = () => {
  const { courseId } = useParams();
  const [episodes, setEpisodes] = useState([]);
  const [newEpisodeTitle, setNewEpisodeTitle] = useState('');
  const [newEpisodeVideo, setNewEpisodeVideo] = useState(null);
  const [newEpisodeAudio, setNewEpisodeAudio] = useState(null);
  const [newYouTubeLink, setNewYouTubeLink] = useState('');
  const [isYouTube, setIsYouTube] = useState(false);

  useEffect(() => {
    fetchEpisodes();
  }, [courseId]);

  const fetchEpisodes = async () => {
    try {
      const response = await axios.get(`http://127.0.0.1:8000/api/courses/${courseId}/episodes`);
      setEpisodes(response.data.data);
    } catch (error) {
      console.error('Error fetching episodes:', error);
    }
  };

  const addEpisode = async () => {
    const formData = new FormData();
    formData.append('title', newEpisodeTitle);

    if (isYouTube) {
      formData.append('youtube_link', newYouTubeLink);
    } else {
      if (newEpisodeVideo) formData.append('video', newEpisodeVideo);
    }

    if (newEpisodeAudio) {
      formData.append('audio', newEpisodeAudio);
    }

    try {
      await axios.post(`http://127.0.0.1:8000/api/courses/${courseId}/episodes`, formData);
      resetForm();
      fetchEpisodes();
    } catch (error) {
      console.error('Error adding episode:', error);
    }
  };

  const resetForm = () => {
    setNewEpisodeTitle('');
    setNewEpisodeVideo(null);
    setNewEpisodeAudio(null);
    setNewYouTubeLink('');
    setIsYouTube(false);
  };

  const deleteEpisode = async (episodeId) => {
    try {
      await axios.delete(`http://127.0.0.1:8000/api/courses/${courseId}/episodes/${episodeId}`);
      fetchEpisodes();
    } catch (error) {
      console.error('Error deleting episode:', error);
    }
  };

  const toggleLock = async (episode) => {
    try {
      if (episode.is_locked) {
        await axios.post(`http://127.0.0.1:8000/api/courses/${courseId}/episodes/${episode.id}/unlock`);
      } else {
        await axios.post(`http://127.0.0.1:8000/api/courses/${courseId}/episodes/${episode.id}/lock`);
      }
      fetchEpisodes();
    } catch (error) {
      console.error('Error toggling lock state:', error);
    }
  };

  return (
    <Box m="20px">
      <Typography variant="h5">Manage Episodes for Course {courseId}</Typography>
      <TextField
        label="Episode Title"
        value={newEpisodeTitle}
        onChange={(e) => setNewEpisodeTitle(e.target.value)}
        fullWidth
        margin="normal"
      />
      <Box display="flex" gap={2} mb={2}>
        <Button 
          variant={isYouTube ? 'contained' : 'outlined'} 
          onClick={() => setIsYouTube(true)} 
          sx={{ 
            mr: 1, 
            backgroundColor: isYouTube ? 'primary.main' : 'transparent', 
            color: isYouTube ? 'white' : 'text.primary' 
          }}
        >
          YouTube Link
        </Button>
        <Button 
          variant={!isYouTube ? 'contained' : 'outlined'} 
          onClick={() => setIsYouTube(false)} 
          sx={{ 
            backgroundColor: !isYouTube ? 'primary.main' : 'transparent', 
            color: !isYouTube ? 'white' : 'text.primary' 
          }}
        >
          Upload Video
        </Button>
      </Box>
      {isYouTube ? (
        <TextField
          label="YouTube Link"
          value={newYouTubeLink}
          onChange={(e) => setNewYouTubeLink(e.target.value)}
          fullWidth
          margin="normal"
          placeholder="https://www.youtube.com/watch?v=VIDEO_ID"
        />
      ) : (
        <input type="file" accept="video/*" onChange={(e) => setNewEpisodeVideo(e.target.files[0])} />
      )}
      <input type="file" accept="audio/*" onChange={(e) => setNewEpisodeAudio(e.target.files[0])} style={{ marginTop: 10 }} />
      <Button onClick={addEpisode} variant="contained" color="primary" sx={{ mt: 2 }}>
        Add Episode
      </Button>
      <Box mt={2} display="flex" flexWrap="wrap" gap={2}>
        {episodes.map((episode) => (
          <Card key={episode.id} sx={{ width: 300 }}>
            {episode.video_path && !episode.youtube_link && (
              <CardMedia component="video" controls src={`http://127.0.0.1:8000/storage/${episode.video_path}`} />
            )}
            {episode.youtube_link && (
              <iframe width="100%" height="150" src={episode.youtube_link.replace("watch?v=", "embed/")} title={episode.title} frameBorder="0" allowFullScreen></iframe>
            )}
            {episode.audio_path && (
              <audio controls>
                <source src={`http://127.0.0.1:8000/storage/${episode.audio_path}`} />
              </audio>
            )}
            <CardContent>
              <Typography variant="h6">{episode.title}</Typography>
              <IconButton onClick={() => toggleLock(episode)} color="warning">
                {episode.is_locked ? <Lock /> : <LockOpen />}
              </IconButton>
              <IconButton onClick={() => deleteEpisode(episode.id)} color="error">
                <DeleteIcon />
              </IconButton>
            </CardContent>
          </Card>
        ))}
      </Box>
    </Box>
  );
};

export default EpisodeManager;