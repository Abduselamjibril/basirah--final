import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Box,
  Button,
  TextField,
  Typography,
  Card,
  CardContent,
  CardMedia,
  IconButton,
  Alert,
  Tooltip,
} from '@mui/material';
import { Edit, Delete, AddCircle, Lock, LockOpen } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const API_URL = 'http://127.0.0.1:8000/api/courses';
const BASE_IMAGE_URL = 'http://127.0.0.1:8000/storage/';

const CourseManager = () => {
  const [courses, setCourses] = useState([]);
  const [newCourseName, setNewCourseName] = useState('');
  const [newCourseDescription, setNewCourseDescription] = useState('');
  const [newCourseImage, setNewCourseImage] = useState(null);
  const [newCourseCategory, setNewCourseCategory] = useState('');
  const [editingCourseId, setEditingCourseId] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const response = await axios.get(API_URL);
      setCourses(response.data.data);
    } catch (err) {
      setError('Failed to fetch courses');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    const formData = new FormData();
    formData.append('name', newCourseName);
    formData.append('description', newCourseDescription);
    formData.append('category', newCourseCategory);
    if (newCourseImage) {
      formData.append('image', newCourseImage);
    }

    try {
      if (editingCourseId) {
        await axios.post(`${API_URL}/${editingCourseId}?_method=PUT`, formData);
        setSuccess('Course updated successfully!');
      } else {
        await axios.post(API_URL, formData);
        setSuccess('Course created successfully!');
      }

      fetchCourses();
      resetForm();
    } catch (err) {
      setError('Failed to submit course');
    }
  };

  const handleEdit = (course) => {
    setNewCourseName(course.name);
    setNewCourseDescription(course.description);
    setNewCourseCategory(course.category);
    setEditingCourseId(course.id);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      fetchCourses();
      setSuccess('Course deleted successfully!');
    } catch (err) {
      setError('Failed to delete course');
    }
  };

  const toggleLock = async (course) => {
    try {
      if (course.is_premium) {
        await axios.post(`${API_URL}/${course.id}/unlock`);
        setSuccess('Course unlocked successfully!');
      } else {
        await axios.post(`${API_URL}/${course.id}/lock`);
        setSuccess('Course locked successfully!');
      }
      fetchCourses();
    } catch (err) {
      setError('Failed to toggle lock state');
    }
  };

  const resetForm = () => {
    setNewCourseName('');
    setNewCourseDescription('');
    setNewCourseImage(null);
    setNewCourseCategory('');
    setEditingCourseId(null);
    setError('');
    setSuccess('');
  };

  return (
    <Box m="20px">
      <Typography variant="h5" color="textPrimary">Course Manager</Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Course Name"
          value={newCourseName}
          onChange={(e) => setNewCourseName(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          label="Course Description"
          value={newCourseDescription}
          onChange={(e) => setNewCourseDescription(e.target.value)}
          fullWidth
          multiline
          rows={4}
          margin="normal"
          required
        />
        <input
          type="file"
          onChange={(e) => setNewCourseImage(e.target.files[0])}
          accept="image/*"
          style={{ display: 'block', margin: '10px 0' }}
        />
        <TextField
          select
          label="Category"
          value={newCourseCategory}
          onChange={(e) => setNewCourseCategory(e.target.value)}
          fullWidth
          SelectProps={{ native: true }}
          margin="normal"
          required
        >
          <option value=""></option>
          <option value="All">All</option>
          <option value="Introduction to Quran">Introduction to Quran</option>
          <option value="Messages in Quran">Messages in Quran</option>
        </TextField>

        {error && <Alert severity="error">{error}</Alert>}
        {success && <Alert severity="success">{success}</Alert>}

        <Button variant="contained" color="primary" type="submit" sx={{ mt: 2 }}>
          {editingCourseId ? 'Update Course' : 'Create Course'}
        </Button>
      </form>

      <Box mt={2} display="flex" flexWrap="wrap" gap={2}>
        {courses.map((course) => (
          <Card key={course.id} sx={{ width: 300 }}>
            {course.image_path && (
              <CardMedia
                component="img"
                height="flex"
                image={`${BASE_IMAGE_URL}${course.image_path}`}
                alt={course.name}
              />
            )}
            <CardContent>
              <Typography variant="h6">{course.name}</Typography>
              <Typography variant="body2" color="textSecondary">
                {course.description}
              </Typography>
              <Typography variant="subtitle2" color="textSecondary" style={{ marginTop: '8px' }}>
                {course.category}
              </Typography>
            </CardContent>
            <Box display="flex" justifyContent="space-between" p={1}>
              <IconButton onClick={() => handleEdit(course)} color="white">
                <Edit />
              </IconButton>
              <IconButton onClick={() => handleDelete(course.id)} color="error">
                <Delete />
              </IconButton>
              <Tooltip title={course.is_premium ? "Unlock Course" : "Lock Course"}>
                <IconButton onClick={() => toggleLock(course)} color="warning">
                  {course.is_premium ? <Lock /> : <LockOpen />}
                </IconButton>
              </Tooltip>
              <Tooltip title="Add Episode">
                <IconButton
                  onClick={() => navigate(`/upload/course/${course.id}/episodes`)}
                  color="white"
                >
                  <AddCircle />
                </IconButton>
              </Tooltip>
            </Box>
          </Card>
        ))}
      </Box>
    </Box>
  );
};

export default CourseManager;